import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { getWorklogs, addWorklogs, editWorklogs, deleteWorklogs } from '../redux/action';
import Calendar from 'react-calendar';
import 'react-calendar/dist/Calendar.css';

function Worklog() {
  const dispatch = useDispatch();
  const worklogs = useSelector((state) => state.worklogs.worklogs);

  const [formworklogData, setFormworklogData] = useState({
    date: '',
    exercise: '',
    duration: '',
    notes: '',
  });

  const [editId, setEditId] = useState(null);
  const [selectedDate, setSelectedDate] = useState(null);

  useEffect(() => {
    dispatch(getWorklogs());
  }, [dispatch]);

  const handleWorklogSubmit = (e) => {
    e.preventDefault();
    if (editId) {
      dispatch(editWorklogs(editId, formworklogData));
      setEditId(null);
    } else {
      dispatch(addWorklogs(formworklogData));
    }
    setFormworklogData({
      date: '',
      exercise: '',
      duration: '',
      notes: '',
    });
  };

  const handleEdit = (log) => {
    setFormworklogData(log);
    setEditId(log.id);
  };

  const handleDelete = (id) => {
    dispatch(deleteWorklogs(id));
  };

  const tileClassName = ({ date }) => {
    const dateStr = date.toISOString().split('T')[0];
    const isLogged = worklogs.some((log) => log.date === dateStr);
    return isLogged ? 'bg-green-300 text-black rounded-full' : null;
  };

  const filteredLogs =
    selectedDate &&
    worklogs.filter(
      (log) => log.date === selectedDate.toISOString().split('T')[0]
    );

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-6">
      <h1 className="text-2xl font-bold">Workout Log</h1>

      {/* Calendar View */}
      <Calendar
        onChange={setSelectedDate}
        value={selectedDate}
        tileClassName={tileClassName}
        className="bg-white rounded shadow p-2"
      />
      {selectedDate && (
        <div className="mt-4 bg-white p-4 rounded shadow">
          <h3 className="text-lg font-semibold mb-2">
            Logs on {selectedDate.toDateString()}
          </h3>
          {filteredLogs.length > 0 ? (
            <ul className="list-disc ml-5 space-y-1">
              {filteredLogs.map((log) => (
                <li key={log.id}>
                  <span className="font-medium">{log.exercise}</span> – {log.duration} min
                </li>
              ))}
            </ul>
          ) : (
            <p>No logs for this day.</p>
          )}
        </div>
      )}

      {/* Form */}
      <form onSubmit={handleWorklogSubmit} className="space-y-4 bg-white p-4 rounded shadow">
        <input
          type="date"
          className="w-full p-2 border rounded"
          value={formworklogData.date}
          onChange={(e) => setFormworklogData({ ...formworklogData, date: e.target.value })}
          required
        />
        <input
          type="text"
          placeholder="Exercise"
          className="w-full p-2 border rounded"
          value={formworklogData.exercise}
          onChange={(e) => setFormworklogData({ ...formworklogData, exercise: e.target.value })}
          required
        />
        <input
          type="text"
          placeholder="Duration (mins)"
          className="w-full p-2 border rounded"
          value={formworklogData.duration}
          onChange={(e) => setFormworklogData({ ...formworklogData, duration: e.target.value })}
          required
        />
        <input
          type="text"
          placeholder="Notes"
          className="w-full p-2 border rounded"
          value={formworklogData.notes}
          onChange={(e) => setFormworklogData({ ...formworklogData, notes: e.target.value })}
        />
        <button className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
          {editId ? 'Update Log' : 'Add Log'}
        </button>
      </form>

      {/* Table */}
      <table className="w-full text-left bg-white rounded shadow">
        <thead>
          <tr className="bg-gray-100 border-b">
            <th className="p-2">Date</th>
            <th className="p-2">Exercise</th>
            <th className="p-2">Duration</th>
            <th className="p-2">Notes</th>
            <th className="p-2">Actions</th>
          </tr>
        </thead>
        <tbody>
          {worklogs.map((log) => (
            <tr key={log.id} className="border-b">
              <td className="p-2">{log.date}</td>
              <td className="p-2">{log.exercise}</td>
              <td className="p-2">{log.duration}</td>
              <td className="p-2">{log.notes}</td>
              <td className="p-2 space-x-2">
                <button
                  onClick={() => handleEdit(log)}
                  className="text-blue-600 hover:underline"
                >
                  Edit
                </button>
                <button
                  onClick={() => handleDelete(log.id)}
                  className="text-red-600 hover:underline"
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default Worklog;
