import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useSelector, useDispatch } from 'react-redux';
import {
  getWorklogsAction,
  deleteWorklogsAction,
} from '../../redux/action';
import Calendar from 'react-calendar';
import 'react-calendar/dist/Calendar.css';
import AddWorkLog from './AddWorkLog';
//Kebab Menu
import { EllipsisVertical } from 'lucide-react';

function Worklog() {
  const dispatch = useDispatch();
  const user = useSelector((state) => state.auth.user);
  const worklogs = useSelector((state) => state.worklog.worklogs);
  //Kebab Menu
  const [openMenuId, setOpenMenuId] = useState(null);
  //Implement Calendar
  const [selectedDate, setSelectedDate] = useState(new Date());
//Flter Based on Date
const [isDateSelected, setIsDateSelected] = useState(false);
  //Date Format
  const formatDate = (date) => {
    const d = new Date(date);
    const year = d.getFullYear();
    const month = `${d.getMonth() + 1}`.padStart(2, '0');
    const day = `${d.getDate()}`.padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

 const logsForSelectedDate = isDateSelected
  ? worklogs.filter((log) => formatDate(log.date) === formatDate(selectedDate))
  : worklogs;

 
  const fetchWorklogs = async () => {
    try {
      const userRes = await axios.get(`http://localhost:5000/users/${user.id}`);
      dispatch(getWorklogsAction(userRes.data.worklogs || []));
    } catch (error) {
      console.error('Failed to fetch worklogs:', error);
    }
  };

  const [editWorkLogs, setEditWorkLogs] = useState(null);
  useEffect(() => {
    if (user?.id) {
      fetchWorklogs();
    }
  }, [user]);


  return (

    <div className="w-full max-w-5xl p-6 mx-auto space-y-6">
      <h1 className="text-2xl font-bold">Workout Log</h1>
      {user && (
        <AddWorkLog editWorkLogs={editWorkLogs} setEditWorkLogs={setEditWorkLogs} />
      )}

      {worklogs.length === 0 ? (
        <p className="p-4 text-center text-gray-600 bg-white border border-gray-100 rounded-lg shadow">No worklogs added yet.</p>
      ) : (
        <div className="grid grid-cols-2 gap-4 space-y-6">
          <Calendar onChange={(date) => {
    setSelectedDate(date);
    setIsDateSelected(true);
  }}
            value={selectedDate}
            className="col-span-1 p-2 border rounded-lg " />
          <div className="col-span-1">
           <h2 className="mb-2 text-xl font-semibold ">
  {isDateSelected ? `Logs for ${formatDate(selectedDate)}` : 'All Workout Logs'}
</h2>
{isDateSelected && (
  <button
    onClick={() => setIsDateSelected(false)}
    className="mb-2 text-sm text-blue-600 underline hover:text-blue-800"
  >
    Clear Filter
  </button>
)}
            {logsForSelectedDate.length === 0 ?
              (<p className="text-gray-600">No logs for this date.</p>)
              : (
                logsForSelectedDate.map(log => (
                  <div key={log.id} className="relative flex flex-col p-4 mb-4 space-y-2 transition bg-white border border-gray-200 rounded-lg shadow dark:border-gray-700 dark:bg-gray-800 hover:shadow-md transitionhover:shadow-md">
                    <div className="flex w-full"><span className="w-32">Exercise</span><span className="w-2">:</span> {log.exercise}</div>
                    <div className="flex w-full"><span className="w-32">Duration</span><span className="w-2">:</span> {log.duration}</div>
                    <div className="flex w-full"><span className="w-32">Notes</span><span className="w-2">:</span> {log.notes}</div>
                    <div className="absolute z-10 flex justify-end right-4 bottom-4 ">
                      <button
                        onClick={() => setOpenMenuId(openMenuId === log.id ? null : log.id)}
                        className="p-2 text-gray-600 bg-white rounded-full shadow-xl hover:text-black"
                      >
                        <EllipsisVertical />
                      </button>

                      {openMenuId === log.id && (
                        <div className="absolute right-0 z-10 mt-2 origin-top-right bg-white border border-gray-200 divide-y divide-gray-100 rounded-lg shadow-lg w-28">
                          <button
                            onClick={() => {
                              setEditWorkLogs(log);
                              setOpenMenuId(null);
                            }}
                            className="w-full px-4 py-2 text-sm text-left text-gray-700 hover:bg-gray-50"
                          >
                            Edit
                          </button>
                          <button
                            onClick={() => {
                                dispatch(deleteWorklogsAction(log.id));
                              setOpenMenuId(null);
                              }}
                            className="w-full px-4 py-2 text-sm text-left text-red-600 hover:bg-gray-50"
                          >
                            Delete
                          </button>
                        </div>
                      )}
                    </div>


                  </div>
                ))
              )}
          </div>
        </div>
      )}
    </div>
  );
}

export default Worklog;
