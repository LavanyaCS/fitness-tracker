import React from 'react'

function Dashboard() {
  return (
    <div>
      Dashborad Lorem ipsum dolor sit amet consectetur, adipisicing elit. Adipisci consequuntur optio nobis temporibus soluta, sapiente deserunt architecto reiciendis, at est corrupti quod maxime delectus totam nemo aut. Ullam, nisi illum.
    </div>
  )
}

export default Dashboard
