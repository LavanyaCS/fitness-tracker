import React from 'react'

function Goals() {
  return (
    <div>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Reprehenderit eaque officia repellat assumenda maxime doloribus soluta facilis voluptatum obcaecati, beatae quia, perspiciatis nemo tenetur cupiditate? Eius sit qui aspernatur illum.
      Lorem ipsum dolor sit amet consectetur adipisicing elit. A sint saepe error rerum tempora dolore provident commodi, eveniet fugit corporis odio molestias, aspernatur neque quisquam molestiae unde. Numquam, dolore nemo!
      Fuga explicabo est nisi ipsum nam fugit unde voluptas reprehenderit perferendis at quia dolores quasi molestias corrupti, sint optio, dicta, vel facilis debitis ad quos. Ut ipsa laudantium a quo.
      Explicabo, corrupti doloribus, consequatur corporis obcaecati perspiciatis quisquam deserunt alias sequi quibusdam in, beatae laboriosam veniam. Esse excepturi molestiae, quidem atque earum, deserunt eligendi ea maxime molestias, sequi ipsam? Dolore?
      Officiis explicabo facere veritatis voluptatibus cumque nisi laborum, rem quidem quibusdam quis minus tenetur? Saepe consectetur iste, voluptate facilis qui magnam vitae accusamus ex rem incidunt eveniet culpa ipsam esse!
      Quibusdam ducimus, veritatis velit aspernatur voluptate maxime corrupti harum architecto molestiae iure nobis consequuntur atque laudantium sit animi dolorum blanditiis nostrum vel cumque. Aliquid atque, excepturi labore minus doloremque ut?
    </div>
  )
}

export default Goals
