import React from 'react'

function Worktracker() {
  return (
    <div>
      hello Lorem ipsum, dolor sit amet consectetur adipisicing elit. Dolorum, quae ex sapiente delectus nihil rem quod quidem optio earum blanditiis soluta nemo, culpa labore vitae, quis atque debitis? Suscipit, excepturi.
    </div>
  )
}

export default Worktracker
