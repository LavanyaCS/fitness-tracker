import React from 'react'

function Profile() {
  return (
    <div>
      Profile Lorem ipsum dolor sit amet consectetur adipisicing elit. Architecto error voluptatem, et illum asperiores possimus, magni itaque molestias blanditiis facere reiciendis ullam, eum ipsa minima natus perspiciatis quibusdam corporis nostrum.
    </div>
  )
}

export default Profile
