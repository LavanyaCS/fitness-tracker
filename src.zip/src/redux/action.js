import axios from "axios";
//Login Logout
export const LOGIN = "LOGIN";
export const LOGOUT = "LOGOUT";

export const login = (user) => ({
    type:LOGIN,
    payload:user,
});
export const logout = () => ({
    type:LOGOUT,
});
//Workout Log Crud
export const GET_WORKLOGS = 'GET_WORKLOGS';
export const ADD_WORKLOGS = 'ADD_WORKLOGS';
export const EDIT_WORKLOGS = 'EDIT_WORKLOGS';
export const DELETE_WORKLOGS = 'DELETE_WORKLOGS';

const baseWorkLogApi = 'http://localhost:5000/worklogs';

// Get all logs
export const getWorklogs = () => async (dispatch) => {
  const response = await axios.get(baseWorkLogApi);
  dispatch({ type: 'GET_WORKLOGS', payload: response.data });
};

// Add a log
export const addWorklogs = (worklog) => async (dispatch) => {
  const response = await axios.post(baseWorkLogApi, worklog);
  dispatch({ type: 'ADD_WORKLOGS', payload: response.data });
};

// Edit a log
export const editWorklogs = (id, editedWorklog) => async (dispatch) => {
  const response = await axios.put(`${baseWorkLogApi}/${id}`, editedWorklog);
  dispatch({ type: 'EDIT_WORKLOGS', payload: response.data });
};

// Delete a log
export const deleteWorklogs = (id) => async (dispatch) => {
  await axios.delete(`${baseWorkLogApi}/${id}`);
  dispatch({ type: 'DELETE_WORKLOGS', payload: id });
};
