import { Link, Routes, Route, useLocation } from 'react-router-dom';
import LoginForm from './pages/Auth/LoginForm';
import SignupForm from './pages/Auth/SignupForm';
import Dashboard from './pages/Dashboard';
import Worktracker from './pages/Worktracker';
import Worklog from './pages/Worklog';
import Goals from './pages/Goals';
import Profile from './pages/Profile';
import Logout from './pages/Auth/Logout';
import Sidebarmenu from './components/Sidebarmenu';

function App() {

  return (
    <div className="flex min-h-screen bg-gray-100">

      <Sidebarmenu />

      {/* Main Content */}
      <main className="flex-1 p-12 xl:p-6">

        <Routes>
          <Route path="/" element={<LoginForm />} />
          <Route path="/sign-up" element={<SignupForm />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/work-tracker" element={<Worktracker />} />
          <Route path="/work-log" element={<Worklog />} />
          <Route path="/goals" element={<Goals />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/logout" element={<Logout />} />
        </Routes>
      </main>
    </div>
  )
}
export default App
